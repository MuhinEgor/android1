#Calculadora en Android que realiza las operaciones mediante el consumo de un WS

*Proyecto realizado como practica en mi segundo diplomado android*

**FUNCIONES**

* Operaciones asincronas
* Consumo de WS mediante el uso de http
* Consumo de WS mediante el uso de la libreria Retrofit

**ScreenShoot**

![screenshot_2017-04-07-18-20-24-718](https://cloud.githubusercontent.com/assets/5818048/25069107/aa934f18-2245-11e7-83f0-4e9c26f8a2dd.jpg)


**SOURCE CODE DEL WS-REST**

https://github.com/parcka/ws-rest-springboot

*Nota: Actualmente el ws se encuentra activo para fines de prueba*

**Descarga del APK** 
* *Pendiente*

**Bugs**

* Consumo mediante http
* Estructura Json

